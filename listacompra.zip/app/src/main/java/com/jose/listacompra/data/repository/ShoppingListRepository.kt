package com.jose.listacompra.data.repository

import android.content.Context
import androidx.room.Room
import com.google.gson.Gson
import com.jose.listacompra.data.local.*
import com.jose.listacompra.domain.model.Aisle
import com.jose.listacompra.domain.model.Category
import com.jose.listacompra.domain.model.Offer
import com.jose.listacompra.domain.model.Product
import com.jose.listacompra.domain.model.ProductSuggestion
import com.jose.listacompra.domain.model.ShoppingList
import com.jose.listacompra.domain.model.Supermarket
import com.jose.listacompra.domain.model.toExport
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class ShoppingListRepository(context: Context) {
    
    private val db = Room.databaseBuilder(
        context.applicationContext,
        ShoppingListDatabase::class.java,
        ShoppingListDatabase.DATABASE_NAME
    ).fallbackToDestructiveMigration()  // Para actualizar versión de BD
     .build()
    
    private val shoppingListDao = db.shoppingListDao()
    private val aisleDao = db.aisleDao()
    private val offerDao = db.offerDao()
    private val productDao = db.productDao()
    private val historyDao = db.purchaseHistoryDao()
    private val categoryDao = db.categoryDao()
    private val purchaseHistoryDao = db.purchaseHistoryDao()
    private val productPriceHistoryDao = db.productPriceHistoryDao()
    private val productFrequencyDao = db.productFrequencyDao()
    private val gson = Gson()
    private val supermarketDao = db.supermarketDao()
    private val supermarketAisleDao = db.supermarketAisleDao()
    private val productAisleMappingDao = db.productAisleMappingDao()

    private val productSupermarketDao = db.productSupermarketAisleDao()

    // ==================== CRUD SUPERMERCADOS ====================

    suspend fun getAllSupermarkets(): List<Supermarket> =
        supermarketDao.getAll().map { it.toDomain() }

    suspend fun addSupermarket(name: String, displayName: String): Long {
        val maxOrder = supermarketDao.getAll().maxOfOrNull { it.orderIndex } ?: -1
        return supermarketDao.insert(
            SupermarketEntity(
                name = name.lowercase(),
                displayName = displayName,
                orderIndex = maxOrder + 1
            )
        )
    }

    // Se corta pasos a seguir 6
//
//    suspend fun deleteSupermarket(id: Long): Boolean {
//        val supermarket = supermarketDao.getById(id) ?: return false
//        if (supermarket.isDefault) return false  // No borrar defaults
//        supermarketDao.delete(supermarket)
//        return true

        // ========== LISTAS DE COMPRAS ==========
    /**
     * Añade producto asignando AUTOMÁTICAMENTE el pasillo correcto
     */
    suspend fun addProductWithAutoAisle(
        productName: String,
        quantity: Float = 1f,
        listId: Long,
        categoryId: Long? = null,
        estimatedPrice: Float? = null
    ): Long {

        // 1. Obtener información de la lista
        val shoppingList = shoppingListDao.getListById(listId)?.toDomain()
            ?: throw IllegalStateException("Lista no encontrada")

        val supermarket = shoppingList.supermarket  // "carrefour", "mercadona", o null

        // 2. Normalizar nombre del producto (para búsquedas)
        val normalizedName = productName.trim().uppercase()

        // 3. Buscar pasillo automático
        val aisleAssignment = findBestAisle(
            productName = normalizedName,
            supermarket = supermarket,
            categoryId = categoryId
        )

        // 4. Construir el aisleMap
        val aisleMap = buildAisleMap(
            supermarket = supermarket,
            aisleName = aisleAssignment?.aisleName,
            existingMap = null
        )

        // 5. Crear producto
        val product = ProductEntity(
            id = 0,
            name = productName.trim(),
            categoryId = categoryId,
            aisleId = null,  // Deprecated
            shoppingListId = listId,
            quantity = quantity,
            estimatedPrice = estimatedPrice,
            offerId = null,
            finalPrice = null,
            isPurchased = false,
            notes = "",
            orderIndex = getNextOrderIndex(listId),
            aisleMap = aisleMap
        )

        val productId = productDao.insertProduct(product)

        // 6. Guardar asignación para futuro (si tenemos supermercado)
        if (supermarket != null && aisleAssignment != null) {
            productSupermarketDao.saveAisle(
                ProductSupermarketAisleEntity(
                    productName = normalizedName,
                    supermarket = supermarket,
                    aisleName = aisleAssignment.aisleName,
                    aisleId = aisleAssignment.aisleId
                )
            )
        }

        return productId
    }

    /**
     * Lógica principal de búsqueda de pasillo
     */
    private suspend fun findBestAisle(
        productName: String,
        supermarket: String?,
        categoryId: Long?
    ): AisleAssignment? {

        // Si no hay supermercado asignado a la lista → usar solo categoría
        if (supermarket == null) {
            return categoryId?.let { getDefaultAisleForCategory(it) }
        }

        // PRIORIDAD 1: Producto exacto ya usado en este super → mismo pasillo
        val exactMatch = productSupermarketDao.getAisleForProduct(productName, supermarket)
        if (exactMatch != null) {
            return AisleAssignment(
                aisleName = exactMatch.aisleName,
                aisleId = exactMatch.aisleId,
                source = "history_exact"
            )
        }

        // PRIORIDAD 2: Producto similar (búsqueda parcial)
        // Ej: busca "Leche" y encuentra "Leche Hacendado" → mismo pasillo
        val productWords = productName.split(" ")
        for (word in productWords) {
            if (word.length >= 3) {  // Palabras de 3+ letras
                val similar = productSupermarketDao.findSimilarProductAisle(word, supermarket)
                if (similar != null) {
                    return AisleAssignment(
                        aisleName = similar,
                        aisleId = null,
                        source = "history_similar"
                    )
                }
            }
        }

        // PRIORIDAD 3: Usar categoría → pasillo por defecto de ese super
        return categoryId?.let {
            getAisleForCategoryInSupermarket(it, supermarket)
        }
    }

    /**
     * Construye el JSON del aisleMap
     */
    private fun buildAisleMap(
        supermarket: String?,
        aisleName: String?,
        existingMap: String?
    ): String {
        val map = existingMap?.let {
            gson.fromJson(it, Map::class.java) as MutableMap<String, String>
        } ?: mutableMapOf()

        // Añadir o actualizar el pasillo para este supermercado
        if (supermarket != null && aisleName != null) {
            map[supermarket] = aisleName
        }

        return gson.toJson(map)
    }

    data class AisleAssignment(
        val aisleName: String,
        val aisleId: Long?,
        val source: String  // "history_exact", "history_similar", "category_default"
    )

    private suspend fun getDefaultAisleForCategory(categoryId: Long): AisleAssignment? {
        // Ej: Lácteos → "Pasillo de Lácteos"
        val category = categoryDao.getCategoryById(categoryId)
        return category?.let {
            AisleAssignment(
                aisleName = "Sección ${it.name}",
                aisleId = null,
                source = "category_default"
            )
        }
    }
// pasos a seguir 4 cortado
//    private suspend fun getAisleForCategoryInSupermarket(
//        categoryId: Long,
//        supermarket: String
//    ): AisleAssignment? {

        suspend fun getActiveLists(): List<ShoppingList> {
        return shoppingListDao.getActiveLists().map { it.toDomain() }
    }
    
    suspend fun getArchivedLists(): List<ShoppingList> {
        return shoppingListDao.getArchivedLists().map { it.toDomain() }
    }
    
    suspend fun getAllLists(): List<ShoppingList> {
        return shoppingListDao.getAllLists().map { it.toDomain() }
    }
    
    suspend fun getListById(id: Long): ShoppingList? {
        return shoppingListDao.getListById(id)?.toDomain()
    }
    
    suspend fun createList(name: String, useDefaultAisles: Boolean = true): Long {
        val list = ShoppingListEntity(
            name = name,
            fechaCreacion = System.currentTimeMillis(),
            estado = "ACTIVA"
        )
        return shoppingListDao.insertList(list)
    }
    
    suspend fun updateList(list: ShoppingList) {
        shoppingListDao.updateList(list.toEntity())
    }
    
    suspend fun deleteList(list: ShoppingList) {
        // Solo permitir eliminar si está archivada
        if (list.isArchived()) {
            shoppingListDao.deleteList(list.toEntity())
        }
    }
    
    suspend fun archiveList(listId: Long) {
        shoppingListDao.archiveList(listId)
    }
    
    suspend fun unarchiveList(listId: Long) {
        shoppingListDao.unarchiveList(listId)
    }
    
    /**
     * Crea una lista por defecto si no existe ninguna
     */
    suspend fun createDefaultListIfNeeded(): Long {
        val lists = shoppingListDao.getAllLists()
        return if (lists.isEmpty()) {
            val defaultList = ShoppingListEntity(
                name = "Mi Lista",
                fechaCreacion = System.currentTimeMillis(),
                estado = "ACTIVA"
            )
            shoppingListDao.insertList(defaultList)
        } else {
            lists.first().id
        }
    }
    
    // ========== OFERTAS ==========
    
    suspend fun getAllOffers(): List<Offer> {
        return offerDao.getAllOffers().map { it.toDomain() }
    }
    
    suspend fun getOfferById(id: Long): Offer? {
        return offerDao.getOfferById(id)?.toDomain()
    }
    
    suspend fun getDefaultOffers(): List<Offer> {
        return offerDao.getDefaultOffers().map { it.toDomain() }
    }
    
    suspend fun addOffer(offer: Offer): Long {
        return offerDao.insertOffer(offer.toEntity())
    }
    
    suspend fun updateOffer(offer: Offer) {
        offerDao.updateOffer(offer.toEntity())
    }
    
    suspend fun deleteOffer(offer: Offer) {
        // No eliminar ofertas por defecto
        if (!offer.isDefault) {
            offerDao.deleteOffer(offer.toEntity())
        }
    }
    
    suspend fun initializeDefaultOffers() {
        val count = offerDao.getOfferCount()
        if (count == 0) {
            // Insertar ofertas predefinidas
            val defaultOffers = Offer.getDefaultOffers().map { it.toEntity() }
            offerDao.insertAll(defaultOffers)
        }
    }
    
    /**
     * Calcula el precio final aplicando una oferta
     */
    fun calculateFinalPrice(quantity: Float, unitPrice: Float, offerCode: String?): Float? {
        if (unitPrice <= 0 || quantity <= 0) return null
        
        return when (offerCode) {
            "3x2" -> {
                val groups = (quantity / 3).toInt()
                val remainder = quantity % 3
                (groups * 2 + remainder) * unitPrice
            }
            "2x1" -> {
                val groups = (quantity / 2).toInt()
                val remainder = quantity % 2
                (groups * 1 + remainder) * unitPrice
            }
            "2nd_50" -> {
                val pairs = (quantity / 2).toInt()
                val remainder = quantity % 2
                (pairs * 1.5f + remainder) * unitPrice
            }
            "2nd_70" -> {
                val pairs = (quantity / 2).toInt()
                val remainder = quantity % 2
                (pairs * 1.3f + remainder) * unitPrice  // 100% + 30%
            }
            "4x3" -> {
                val groups = (quantity / 4).toInt()
                val remainder = quantity % 4
                (groups * 3 + remainder) * unitPrice
            }
            else -> quantity * unitPrice  // Sin oferta o custom manual
        }
    }

    /**
     * Calcula el precio final aplicando una oferta (versión suspend con OfferEntity)
     */
    suspend fun calculateFinalPrice(quantity: Float, unitPrice: Float, offer: OfferEntity?): Float {
        return when (offer?.code) {
            "3x2" -> {
                // Lleva 3 paga 2
                val groups = (quantity / 3).toInt()
                val remainder = quantity % 3
                (groups * 2 + remainder) * unitPrice
            }
            "2x1" -> {
                // Lleva 2 paga 1
                val groups = (quantity / 2).toInt()
                val remainder = quantity % 2
                (groups * 1 + remainder) * unitPrice
            }
            "2nd_50" -> {
                // 2ª unidad -50%
                val pairs = (quantity / 2).toInt()
                val remainder = quantity % 2
                (pairs * 1.5f + remainder) * unitPrice
            }
            "2nd_70" -> {
                // 2ª unidad -70%
                val pairs = (quantity / 2).toInt()
                val remainder = quantity % 2
                (pairs * 1.3f + remainder) * unitPrice
            }
            "4x3" -> {
                // Lleva 4 paga 3
                val groups = (quantity / 4).toInt()
                val remainder = quantity % 4
                (groups * 3 + remainder) * unitPrice
            }
            else -> quantity * unitPrice
        }
    }
    
    /**
     * Calcula el precio final para un producto con su oferta asignada
     */
    suspend fun calculateProductFinalPrice(product: Product): Float? {
        if (product.estimatedPrice == null) return null
        
        val offer = product.offerId?.let { offerDao.getOfferById(it)?.toDomain() }
        return calculateFinalPrice(product.quantity, product.estimatedPrice, offer?.code)
    }
    
    // ========== PASILLOS ==========
    
    suspend fun getAllAisles(): List<Aisle> {
        return aisleDao.getAllAisles().map { it.toDomain() }
    }
    
    suspend fun addAisle(aisle: Aisle): Long {
        return aisleDao.insertAisle(aisle.toEntity())
    }
    
    suspend fun updateAisle(aisle: Aisle) {
        aisleDao.updateAisle(aisle.toEntity())
    }
    
    suspend fun deleteAisle(aisle: Aisle) {
        aisleDao.deleteAisle(aisle.toEntity())
    }
    
    /**
     * Reordena los pasillos actualizando sus orderIndex
     */
    suspend fun reorderAisles(reorderedAisles: List<Aisle>) {
        // Actualizar el orderIndex de cada pasillo según su nueva posición
        val updatedAisles = reorderedAisles.mapIndexed { index, aisle ->
            aisle.copy(orderIndex = index).toEntity()
        }
        aisleDao.updateAisles(updatedAisles)
    }
    
    suspend fun initializeDefaultAisles() {
        val existing = aisleDao.getAllAisles()
        if (existing.isEmpty()) {
            Aisle.getDefaultAisles().forEach { 
                aisleDao.insertAisle(it.toEntity())
            }
        }
    }
    
    // ========== PRODUCTOS ==========

    suspend fun getAllProducts(listId: Long, sortMode: SortMode = SortMode.CATEGORY): List<Product> {
        val list = shoppingListDao.getListById(listId)?.toDomain()

        return when (sortMode) {
            SortMode.CATEGORY -> {
                productDao.getAllProductsByCategory(listId).map { it.toDomain() }
            }
            SortMode.AISLE -> {
                val superName = list?.supermarket ?: return getAllProducts(listId, SortMode.CATEGORY)
                // Si no hay supermercado asignado, fallback a categoría
                productDao.getAllProductsByAisle(listId, "$.${superName}")
                    .map { it.toDomain() }
            }
        }
    }

    enum class SortMode { CATEGORY, AISLE }
    
    suspend fun getProductsByAisle(listId: Long, aisleId: Long): List<Product> {
        return productDao.getProductsByAisle(listId, aisleId).map { it.toDomain() }
    }
    
    /**
     * Añade un producto calculando automáticamente el precio final con oferta
     */
    suspend fun addProduct(product: Product): Long {
        val finalPrice = calculateProductFinalPrice(product)
        val productWithFinalPrice = product.copy(finalPrice = finalPrice)
        return productDao.insertProduct(productWithFinalPrice.toEntity())
    }
    
    /**
     * Actualiza un producto existente con nuevos datos
     */
    suspend fun updateProduct(product: Product) {
        val finalPrice = calculateProductFinalPrice(product)
        val productWithFinalPrice = product.copy(finalPrice = finalPrice)
        productDao.updateProduct(productWithFinalPrice.toEntity())
    }
    
    suspend fun deleteProduct(product: Product) {
        productDao.deleteProduct(product.toEntity())
    }
    
    suspend fun toggleProductPurchased(product: Product) {
        val updated = product.copy(isPurchased = !product.isPurchased)
        productDao.updateProduct(updated.toEntity())
    }
    
    suspend fun deletePurchasedProducts(listId: Long) {
        productDao.deletePurchasedProducts(listId)
    }
    
    suspend fun deleteAllProductsFromList(listId: Long) {
        productDao.deleteAllProducts(listId)
    }
    
    // ========== TOTALES ==========
    
    /**
     * Obtiene los totales calculados: con ofertas, sin ofertas y ahorro
     */
    fun getTotals(listId: Long): Flow<TotalsResult> = flow {
        val products = productDao.getAllProducts(listId).map { it.toDomain() }
        
        val totalWithoutOffers = products.sumOf { 
            it.totalPriceWithoutOffer().toDouble() 
        }.toFloat()
        
        val totalWithOffers = products.sumOf { 
            it.finalPriceToPay().toDouble() 
        }.toFloat()
        
        val savings = totalWithoutOffers - totalWithOffers
        
        emit(TotalsResult(
            totalWithoutOffers = totalWithoutOffers,
            totalWithOffers = totalWithOffers,
            savings = savings
        ))
    }
    
    fun getTotalEstimate(listId: Long): Flow<Float> = flow {
        val products = productDao.getAllProducts(listId).map { it.toDomain() }
        val total = products.sumOf { it.finalPriceToPay().toDouble() }.toFloat()
        emit(total)
    }
    
    data class TotalsResult(
        val totalWithoutOffers: Float,
        val totalWithOffers: Float,
        val savings: Float
    )
    
    // ========== EXPORT/IMPORT JSON ==========
    
    suspend fun exportToJson(listId: Long): String {
        val aisles = aisleDao.getAllAisles().map { it.toDomain() }
        val products = productDao.getAllProducts(listId).map { it.toDomain() }
        
        val export = com.jose.listacompra.domain.model.ShoppingListExport(
            aisles = aisles.map { it.toExport() },
            products = products.map { it.toExport() }
        )
        
        return gson.toJson(export)
    }
    
    suspend fun importFromJson(json: String, listId: Long): Boolean {
        return try {
            val export = gson.fromJson(json, com.jose.listacompra.domain.model.ShoppingListExport::class.java)

            // Limpiar datos actuales de la lista
            productDao.deleteAllProducts(listId)

            // Importar pasillos (solo custom)
            export.aisles.filter { !it.isDefault }.forEach { aisle ->
                aisleDao.insertAisle(
                    AisleEntity(
                        id = aisle.id,
                        name = aisle.name,
                        emoji = aisle.emoji,
                        orderIndex = aisle.orderIndex,
                        isDefault = aisle.isDefault
                    )
                )
            }

            // Importar productos
            export.products.forEach { product ->
                productDao.insertProduct(
                    ProductEntity(
                        id = 0, // Nuevo ID autogenerado
                        name = product.name,
                        aisleId = product.aisleId,
                        shoppingListId = listId,
                        quantity = product.quantity,
                        estimatedPrice = product.estimatedPrice,
                        offerId = null, // Las ofertas no se exportan/importan
                        finalPrice = null,
                        isPurchased = product.isPurchased,
                        notes = product.notes,
                        orderIndex = product.orderIndex
                    )
                )
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    // ========== HISTORIAL DE PRODUCTOS (AUTOCOMPLETADO) ==========

    suspend fun findProductSuggestions(query: String): List<ProductSuggestion> {
        if (query.length < 2) return emptyList()
        return historyDao.findSuggestions(query.lowercase()).map { it.toSuggestion() }
    }

    suspend fun saveToHistory(name: String, aisleId: Long, quantity: Float, price: Float?) {
        val normalizedName = name.lowercase().trim()
        val existing = historyDao.findByName(normalizedName)

        if (existing != null) {
            historyDao.updateUsage(normalizedName, quantity, price)
        } else {
            historyDao.insert(
                ProductHistoryEntity(
                    name = normalizedName,
                    originalName = name.trim(),
                    aisleId = aisleId,
                    lastQuantity = quantity,
                    lastPrice = price
                )
            )
        }
    }

    suspend fun getFrequentProducts(): List<ProductSuggestion> {
        return historyDao.getMostFrequent().map { it.toSuggestion() }
    }

    suspend fun isHistoryEmpty(): Boolean {
        return historyDao.getMostFrequent().isEmpty()
    }

    private fun ProductHistoryEntity.toSuggestion(): ProductSuggestion {
        return ProductSuggestion(
            name = this.originalName,
            aisleId = this.aisleId,
            suggestedQuantity = this.lastQuantity,
            suggestedPrice = this.lastPrice,
            usageCount = this.usageCount
        )
    }
    
    // ========== HISTORIAL DE COMPRAS (TICKETS) ==========
    
    /**
     * Guarda una compra completa con todos sus productos
     */
    suspend fun savePurchase(
        total: Float,
        numProductos: Int,
        tienda: String = "Carrefour",
        ahorro: Float = 0f,
        products: List<Triple<String, Float, String?>> // nombre, precio, pasillo
    ): Long {
        // 1. Guardar la compra
        val purchase = PurchaseHistoryEntity(
            fecha = System.currentTimeMillis(),
            total = total,
            tienda = tienda,
            numProductos = numProductos,
            ahorroTotal = ahorro
        )
        val purchaseId = purchaseHistoryDao.insertPurchase(purchase)
        
        // 2. Guardar cada producto con su precio
        val priceRecords = products.map { (name, price, aisle) ->
            ProductPriceHistoryEntity(
                purchaseId = purchaseId,
                productName = name.uppercase().trim(),
                price = price,
                aisle = aisle,
                fecha = System.currentTimeMillis()
            )
        }
        productPriceHistoryDao.insertAllPriceRecords(priceRecords)
        
        // 3. Actualizar frecuencias
        products.forEach { (name, _, _) ->
            updateProductFrequency(name.uppercase().trim())
        }
        
        return purchaseId
    }
    
    /**
     * Actualiza o crea la frecuencia de un producto
     */
    private suspend fun updateProductFrequency(productName: String) {
        val existing = productFrequencyDao.getFrequencyForProduct(productName)
        val now = System.currentTimeMillis()
        
        if (existing != null) {
            // Calcular días desde última compra
            val daysSinceLast = (now - existing.lastPurchaseDate) / (1000 * 60 * 60 * 24)
            val newCount = existing.timesPurchased + 1
            
            // Calcular promedio de días entre compras
            val newAverage = if (existing.averageDaysBetween != null) {
                ((existing.averageDaysBetween * (newCount - 1)) + daysSinceLast) / newCount
            } else {
                daysSinceLast.toFloat()
            }
            
            // Estimar próxima compra
            val nextPurchase = now + (newAverage * 24 * 60 * 60 * 1000).toLong()
            
            productFrequencyDao.insertOrUpdateFrequency(
                existing.copy(
                    timesPurchased = newCount,
                    averageDaysBetween = newAverage,
                    lastPurchaseDate = now,
                    estimatedNextDate = nextPurchase
                )
            )
        } else {
            // Producto nuevo
            productFrequencyDao.insertOrUpdateFrequency(
                ProductFrequencyEntity(
                    productName = productName,
                    timesPurchased = 1,
                    lastPurchaseDate = now
                )
            )
        }
    }
    
    /**
     * Obtiene productos que probablemente necesites comprar
     */
    suspend fun getSuggestedProductsByFrequency(): List<ProductFrequencyEntity> {
        val now = System.currentTimeMillis()
        return productFrequencyDao.getProductsDueForPurchase(now)
            .sortedByDescending { it.timesPurchased }
    }
    
    /**
     * Obtiene el precio promedio de un producto
     */
    suspend fun getAveragePriceForProduct(name: String): Float? {
        return productPriceHistoryDao.getAveragePriceForProduct(name.uppercase().trim())
    }
    
    /**
     * Obtiene historial de precios de un producto
     */
    suspend fun getPriceHistoryForProduct(name: String): List<ProductPriceHistoryEntity> {
        return productPriceHistoryDao.getPriceHistoryForProduct(name.uppercase().trim())
    }
    
    /**
     * Obtiene los productos más comprados
     */
    suspend fun getMostFrequentProducts(): List<ProductFrequencyEntity> {
        return productFrequencyDao.getMostFrequentProducts()
    }
    
    /**
     * Obtiene todas las compras
     */
    suspend fun getAllPurchases(): List<PurchaseHistoryEntity> {
        return purchaseHistoryDao.getAllPurchases()
    }
    
    /**
     * Obtiene estadísticas de gasto
     */
    suspend fun getSpendingStats(): Triple<Float?, Float, Int> {
        val average = purchaseHistoryDao.getAveragePurchaseAmount() ?: 0f
        val totalSpent = purchaseHistoryDao.getTotalSpentSince(0) ?: 0f
        val totalPurchases = purchaseHistoryDao.getAllPurchases().size
        return Triple(average, totalSpent, totalPurchases)
    }

    // ========== CATEGORÍAS ==========
    suspend fun getAllCategories(): List<Category> {
        return categoryDao.getAllCategories().map { it.toDomain() }
    }

    suspend fun addCategory(category: Category): Long {
        return categoryDao.insertCategory(category.toEntity())
    }

    suspend fun updateCategory(category: Category) {
        categoryDao.updateCategory(category.toEntity())
    }

    suspend fun deleteCategory(category: Category) {
        categoryDao.deleteCategory(category.toEntity())
    }

    suspend fun reorderCategories(reorderedCategories: List<Category>) {
        val updatedCategories = reorderedCategories.mapIndexed { index, category ->
            category.copy(orderIndex = index).toEntity()
        }
        categoryDao.updateCategories(updatedCategories)
    }

    suspend fun initializeDefaultCategories() {
        val existing = categoryDao.getAllCategories()
        if (existing.isEmpty()) {
            Category.getDefaultCategories().forEach { categoryDao.insertCategory(it.toEntity()) }
        }
    }

    suspend fun getAllProductsByCategory(listId: Long): List<Product> {
        return productDao.getAllProductsByCategory(listId).map { it.toDomain() }
    }
    /**
     * Actualiza la foto de un producto
     * @param productId ID del producto
     * @param photoUri URI de la imagen (null para eliminar)
     */
    suspend fun updateProductPhoto(productId: Long, photoUri: String?) {
        val product = productDao.getProductById(productId) ?: return

        val updatedEntity = product.copy(
            photoUri = photoUri,
            photoTimestamp = if (photoUri != null) System.currentTimeMillis() else null,
            isPhotoUserSelected = photoUri != null
        )

        productDao.updateProduct(updatedEntity)
    }

    /**
     * Elimina la foto de un producto
     */
    suspend fun deleteProductPhoto(productId: Long) {
        updateProductPhoto(productId, null)
    }

    /**
     * Guarda una foto para un producto nuevo
     * Usar despues de insertar el producto
     */
    suspend fun saveProductWithPhoto(
        productId: Long,
        photoUri: String
    ) {
        updateProductPhoto(productId, photoUri)
    }
}


